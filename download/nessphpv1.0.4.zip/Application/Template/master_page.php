<!DOCTYPE html>
<html>
<head>
	<title>New Application | Ness PHP</title>
</head>
<body>

<?php 
	/**
	 * This line below must me available in all your master pages.
	 * echo $this->contents; means your content place holder. Your data in
	 * views will be loaded here.
	 */
	echo $this->contents;
?>

</body>
</html>